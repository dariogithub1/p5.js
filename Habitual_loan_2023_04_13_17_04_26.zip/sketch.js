function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let brushSize = 20; // size of brush
let brushColor; // color of brush
let previousPosition; // previous position of mouse

function setup() {
  createCanvas(400, 400);
  background(255);
  brushColor = color(0); // set brush color to black
  strokeWeight(brushSize);
}

function draw() {
  if (mouseIsPressed) { // if mouse is pressed, draw with brush
    stroke(brushColor);
    line(previousPosition.x, previousPosition.y, mouseX, mouseY);
  }
  previousPosition = createVector(mouseX, mouseY); // update previous position
}

function keyPressed() {
  if (key === 'r') { // if 'r' key is pressed, clear canvas
    background(255);
  } else if (key === 'b') { // if 'b' key is pressed, change brush color to blue
    brushColor = color(0, 0, 255);
  } else if (key === 'g') { // if 'g' key is pressed, change brush color to green
    brushColor = color(0, 255, 0);
  } else if (key === 'y') { // if 'y' key is pressed, change brush color to yellow
    brushColor = color(255, 255, 0);
  }
}

function mouseClicked() {
  // randomly change brush size and color when mouse is clicked
  brushSize = random(10, 30);
  brushColor = color(random(255), random(255), random(255));
  strokeWeight(brushSize);
}
